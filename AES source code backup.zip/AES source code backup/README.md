# Description
This is the source code for "Advance Election System" or "AES", developed at "Birla Institute of technology, Mesra" or "BIT Mesra" by Palash Chatterjee of BCA batch 2022 during the Ist Semester

# Licence 
This software is licenced under the "Creative Commons" licence, free to use, modify and ddistribute with proper attribution